package com.example.memorygame
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import kotlin.collections.ArrayList

class GameScreen : AppCompatActivity() {
    private var button1: Button? = null
    private var button2: Button? = null
    private var button3: Button? = null
    private var button4: Button? = null
    private var button5: Button? = null
    private var button6: Button? = null
    private var button7: Button? = null
    private var button8: Button? = null
    private var button9: Button? = null
    private var button10: Button? = null
    private var button11: Button? = null
    private var button12: Button? = null
    private var bandeira = 0
    private var conquista = 0
    private var foquete = 0
    private var magnetico = 0
    private var diamante = 0
    private var trofeu = 0
    private var amnesia2 = 0
    private var clicked = 0
    private var turnOver = false
    private var lastClicked = -1
    @SuppressLint("SetTextI18n")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.game_screen)
        SetUp()
        val images: List<Int?> = ArrayList(Arrays.asList(magnetico, conquista, diamante, foquete, trofeu, bandeira, magnetico, conquista, diamante, foquete, trofeu, bandeira))
        val buttons: List<Button> = ArrayList<Button>(Arrays.asList(
                button1, button2, button3, button4,
                button5, button6, button7, button8,
                button9, button10, button11, button12))
        Collections.shuffle(images)
        for (i in 0..11) {
            buttons[i].text = "cardBack"
            buttons[i].textSize = 0.0f
            buttons[i].setOnClickListener {
                if (buttons[i].text === "cardBack" && !turnOver) {
                    buttons[i].setBackgroundResource(images[i]!!)
                    buttons[i].setText(images[i]!!)
                    if (clicked == 0) {
                        lastClicked = i
                    }
                    clicked++
                } else if (buttons[i].text !== "cardBack") {
                    buttons[i].setBackgroundResource(amnesia2)
                    buttons[i].text = "cardBack"
                    clicked--
                }
                if (clicked == 2) {
                    turnOver = true
                    if (buttons[i].text === buttons[lastClicked].text) {
                        buttons[i].isEnabled = false
                        buttons[lastClicked].isEnabled = false
                        turnOver = false
                        clicked = 0
                    }
                } else if (clicked == 0) {
                    turnOver = false
                }
            }
        }
    }
    private fun SetUp() {
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        button10 = findViewById(R.id.button10)
        button11 = findViewById(R.id.button11)
        button12 = findViewById(R.id.button12)
        amnesia2 = R.drawable.amnesia2
        magnetico = R.drawable.magnetico
        conquista = R.drawable.conquista
        diamante = R.drawable.diamante
        foquete = R.drawable.foguete
        bandeira = R.drawable.bandeira
        trofeu = R.drawable.trofeu
    }
}