package com.example.memorygame
import android.R
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class HomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.example.memorygame.R.layout.home_screen)
        goToGameScreen()
    }

    private fun goToGameScreen(){
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent( this, GameScreen::class.java)
            startActivity(intent)
        }, 5000)
    }


}