package com.example.memorygame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ResultScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.result_screen)
    }
}